import express from "express";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const PORT = process.env.PORT || 3000;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

function isHttpUrl(value) {
  try {
    const u = new URL(value);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}

app.post("/api/check-url", (req, res) => {
  const { url } = req.body || {};
  if (!url || !isHttpUrl(url)) {
    return res.status(400).json({ ok: false, error: "Please enter a valid http/https URL." });
  }

  const parsed = new URL(url);
  res.json({
    ok: true,
    host: parsed.hostname,
    message: "URL is valid. Only use media you own or are authorized to download."
  });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
