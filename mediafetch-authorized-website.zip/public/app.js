const form = document.getElementById("urlForm");
const input = document.getElementById("url");
const result = document.getElementById("result");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  result.classList.remove("hidden");
  result.textContent = "Checking...";

  try {
    const r = await fetch("/api/check-url", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({url: input.value.trim()})
    });
    const data = await r.json();

    if (!r.ok) throw new Error(data.error || "Request failed");
    result.textContent = `Valid URL: ${data.host}. ${data.message}`;
  } catch (err) {
    result.textContent = err.message;
    result.style.background = "#fff0f0";
  }
});
